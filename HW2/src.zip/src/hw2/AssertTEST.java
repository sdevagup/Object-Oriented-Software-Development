package hw2;
import java.util.*;
import junit.framework.TestCase;


public class AssertTEST extends TestCase{
	
		public void test_minValue() {
	
		/*-7 == minValue(new double[] { -7 }) -7 == minValue(new double[] { 1, -4,
				 * -7, 7, 8, 11 }) -13 == minValue(new double[] { -13, -4, -7, 7, 8, 11 })
				 * -9 == minValue(new double[] { 1, -4, -7, 7, 8, 11, -9 })
				 */
		double[] test1 = new double[] { 1, -4, -7, 7, 8, 11, -9 };
		assertTrue(AssertExp1.minValue(test1) == -9);
		
		double[] test2 = new double[] { -7 };
		assertTrue(AssertExp1.minValue(test2) == -7);
		
		double[] test3 = new double[] { 1, -4, -7, 7, 8, 11 };
		assertTrue(AssertExp1.minValue(test3) == -7);
		
		double[] test4 = new double[] { -13, -4, -7, 7, 8, 11 };
		assertTrue(AssertExp1.minValue(test4) == -13);
		
		double[] test5 = new double[] { -13, -4, -7, 7, 8, 11 };
		assertTrue(AssertExp1.minValue(test5) == -13);
		}
	
	public void test_minPosition() {
		
		/* * 0 == minPosition(new double[] { -7 }) 2 == minPosition(new double[] { 1,
				 * -4, -7, 7, 8, 11 }) 0 == minPosition(new double[] { -13, -4, -7, 7, 8, 11
				 * }) 6 == minPosition(new double[] { 1, -4, -7, 7, 8, 11, -9 }) */
		
		double[] test1 = new double[] { -7 };
		assertTrue(AssertExp1.minPosition(test1) == 0);
		
		double[] test2 = new double[] { 1,-4, -7, 7, 8, 11 };
		assertTrue(AssertExp1.minPosition(test2) == 2);
		
		double[] test3 = new double[] { -13, -4, -7, 7, 8, 11 };
		assertTrue(AssertExp1.minPosition(test3) == 0);
		
		double[] test4 = new double[] { 1, -4, -7, 7, 8, 11, -9 };
		assertTrue(AssertExp1.minPosition(test4) == 6);
	
	}
	
	
	public void test_numUnique() {
		
		/* 0 == numUnique(new double[] { }) 1 == numUnique(new double[] { 11 }) 1 ==
				 * numUnique(new double[] { 11, 11, 11, 11 }) 8 == numUnique(new double[] {
				 * 11, 11, 11, 11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66, 77, 88, 88 }) 8
				 * == numUnique(new double[] { 11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66,
				 * 77, 88 })
				 */
		
		double[] test1 = new double[] {};
		assertTrue(AssertExp1.numUnique(test1) == 0);
		
		double[] test2 = new double[] {11};
		assertTrue(AssertExp1.numUnique(test2) == 1);
		
		double[] test3 = new double[] { 11, 11, 11, 11 };
		assertTrue(AssertExp1.numUnique(test3) == 1);
		
		double[] test4 = new double[] { 11, 11, 11, 11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66, 77, 88, 88 };
		assertTrue(AssertExp1.numUnique(test4) == 8);
		
		double[] test5 = new double[] { 11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66, 77, 88 };
		assertTrue(AssertExp1.numUnique(test5) == 8);
		
		
				
	}
	
	
	public void test_removeDuplicates() {
	/*	 new double[] { } == removeDuplicates(new double[] { }) 
	 * 	new double[] { 11} == removeDuplicates(new double[] { 11 }) == removeDuplicates(new double[] { 11, 11, 11, 11 }) 
		new double[] { 11, 22, 33, 44, 55, 66, 77,88 } == removeDuplicates(new double[] { 11, 11, 11, 11, 22, 33, 44, 44,
				 * 44, 44, 44, 55, 55, 66, 77, 88, 88 }) == removeDuplicates(new double[] {
				 * 11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66, 77, 88 })
				 */
		double[] test1 = new double[] { };
		double[] test2 = new double[] { };
		double[] test3 = new double[] { 11};
		double[] test4 = new double[] { 11};
		double[] test5 = new double[] { 11, 11, 11, 11 };
		double[] test6 = new double[] {11,22,33,44,55,66,77,88};
		double[] test7 = new double[] { 11, 11, 11, 11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66, 77, 88, 88 };
		double[] test8 = new double[] {11, 22, 33, 44, 44, 44, 44, 44, 55, 55, 66, 77, 88 };
		assertTrue(Arrays.equals(AssertExp1.removeDuplicates(test1), AssertExp1.removeDuplicates(test2)));
		assertTrue(Arrays.equals(AssertExp1.removeDuplicates(test4), AssertExp1.removeDuplicates(test3)));
		assertTrue(Arrays.equals(AssertExp1.removeDuplicates(test4), AssertExp1.removeDuplicates(test5)));
		assertTrue(Arrays.equals(AssertExp1.removeDuplicates(test7), AssertExp1.removeDuplicates(test6)));
		assertTrue(Arrays.equals(AssertExp1.removeDuplicates(test8), AssertExp1.removeDuplicates(test7)));
	}
}
