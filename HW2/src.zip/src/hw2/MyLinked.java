package hw2;
//import junit.framework.Assert;
import org.junit.Assert;
import junit.framework.TestCase;
import java.util.*;
import java.util.Collections;

public class MyLinked extends TestCase{
    static class Node {
        public Node() { }
        public double item;
        public Node next;
    }

    int N;
    Node first;

    public MyLinked () {
        first = null;
        N = 0;
        assert checkInvariants ();
    }


    private boolean checkInvariants() {
        assert((N != 0) || (first == null));
        Node x = first;
        for (int i = 0; i < N; i++) {
            if (x==null) {
                return false;
            }
            x = x.next;
        }
        assert(x == null);
        return true;
    }

  
    public boolean isEmpty () { return first == null; }
    public int size () { return N; }
    public void add (double item) {
        Node newfirst = new Node ();
        newfirst.item = item;
        newfirst.next = first;
        first = newfirst;
        N++;
    }
	
 
    // delete the kth element
    public void delete (int k) {
        if (k < 0 || k >= N) throw new IllegalArgumentException ();
    //****************************************************************

        Node n = first;
        ArrayList<Node> array1 = new ArrayList<Node>();
        ArrayList<Node> array2 = new ArrayList<Node>();
       copy(array1,n);
      // while (n != null) {
    	//   array1.add(n);
   		//n = n.next;
   		//System.out.println(n);
      
        int init_size = array1.size();
        
        if( (k == N-1)&&(k !=0)) {
         	while (n.next.next != null) {
         		n = n.next;
         		assert(n.next != null);
         	}
         	n.next = null;
         	copy(array2,n);
         	assert(array1.size() != array2.size());	
         }
          
        
         if (k == 0) {
        	first = first.next;
        	copy(array2,first);
        	assert(array1.size() != array2.size());	
         }
         
         if( (k != N-1)&&(k !=0)) {
         	for (int i = 0; i < k-1; i++) {
         		n = n.next;
         	}
         	assert(n.next.next != null && n.next != null);
         	n.next = n.next.next;
         	copy(array2,n);
         	assert(array1.size() != array2.size());	
         }
          
        N--;
        //****************************************************************
     
        assert checkInvariants ();
    }  
    
 /*   public void delete (int k) {
        if (k < 0 || k >= N) throw new IllegalArgumentException ();

        Boolean deletedNode = false;

        if(k==0 && N==1) {
        	first = null;
        	deletedNode = true;
        }
  
        if(!deletedNode && k==1 && N==2) {
        	first.next = null;
        	deletedNode = true;
        }
        
        if(!deletedNode && k==0) {
        	first = first.next;
        	deletedNode = true;
        }
        
        if(!deletedNode && k==N-1) {
        	Node x = first;
            for (int i = 0; i < N; i++) {
                if (i==N-2) {
                    x.next = null;
                    deletedNode = true;
                    break;
                }
                x = x.next;
            }
        }
        
        if(!deletedNode) {
        	Node x = first;
        	for(int i = 1; i < N; i++) {
        		if(k==i) {
        			x.next = x.next.next;
        			deletedNode = true;
        			break;
        		}
        		x = x.next;
        	}
        }
        
        assert deletedNode;
        N--;
        assert checkInvariants ();
    }*/
   // reverse the list "in place"... without creating any new nodes
    public void reverse () {
    	 //****************************************************************
    	    Node p = null , n = first;
    	    ArrayList<Node> array = new ArrayList<Node>();
    	    for ( ; n != null; ) {
    	        Node temp = n.next;
    	        n.next = p;
    	        p = n;
    	        n = temp;
    	    }
    	    ArrayList<Node> rev = new ArrayList<Node>();
    	    //copy(rev_list,p);
    	    Collections.reverse(rev);
    	    assert(rev.equals(array));
    	    assert(array.equals(array));
    	    first = p;
    	    assert checkInvariants ();
    	    //****************************************************************

    	}/*
    
    public void reverse() {
        if (N == 0 || N == 1 || first == null) {
            return;
        }

        Node previous = null;
        Node current = first;
        Node next;
        while (current != null) {
            next = current.next;
            current.next = previous;
            previous = current;
            current = next;
        }

        first = previous;
        assert checkInvariants();
    }*/

    
 // remove 
    public void remove (double item) {
    	
        //****************************************************************
        
                if (N > 0) {
                    Node temp = new Node();
                    temp.next = first;
                    Node n = temp;
                    
                    ArrayList<Node> array1 = new ArrayList<Node>();
                    copy(array1,n);
                
                    for (;n.next != null;) {
                   /* if (item == n.next.item) {
                      n.next = n.next.next;
                       N--;
                       ArrayList<Node> array2 = new ArrayList<Node>();
                       copy(array2,n);
                  assert(!array1.equals(array2));
                  assert(array1.size() != (array2.size()));
                        }
                    else	
                    	n = n.next;
                    } */
                    	if (item != n.next.item) {	
                          	n = n.next;
                          }
                        
                    else {
                        n.next = n.next.next;
                         N--;
                         ArrayList<Node> array2 = new ArrayList<Node>();
                         copy(array2,n);
                        assert(!array1.equals(array2));
                        assert(array1.size() != (array2.size()));
                                     }
                      
                    ArrayList<Node> array = new ArrayList<Node>();
                    copy(array,temp.next);
                    assert(array.indexOf(item) < 0);
                    first = temp.next;
                }
                }
                assert checkInvariants ();}
    
    			boolean copy(ArrayList<Node> l, Node n) {
    			for (;n != null;) {
    				l.add(n);
    				n = n.next;
    				System.out.println(n);
    				}return true; }   
    
 /*   
    public void remove (double item) {
    	 
    	if(first==null) return;
    	while(first!=null && first.item==item) {
    		if(first.next==null) { 
    			first = null; 
    			N--;
    		}
    		else { 
    			first = first.next;
    			N--;
    		}
    	}
  
		Node a = first;
		Node b = first;
		while(a!=null) {
			while(a!=null && a.item!=item) {
				b = a;
				a = a.next;
			}
			if(a==null) { return; }
			b.next = a.next; 
			a = a.next;
			N--;
		}    
        assert checkInvariants ();
    }

    
    */
  //****************************************************************


	//****************************************************************  

/* // TODO: CONVERT THE FOLLOWING TO JUNIT TESTS

        private static void testDelete () {
        MyLinked b = new MyLinked ();
        b.add (1);
        print ("singleton", b);
        b.delete (0);
        print ("deleted", b);
        for (double i = 1; i < 13; i++) {
            b.add (i);
        }
        print ("bigger list", b);
        b.delete (0);
        print ("deleted at beginning", b);
        b.delete (10);
        print ("deleted at end", b);
        b.delete (4);
        print ("deleted in middle", b);
    }
    private static void testReverse () {
        MyLinked b = new MyLinked ();
        b.reverse ();
        print ("reverse empty", b);
        b.add (1);
        print ("singleton", b);
        b.reverse ();
        print ("reverse singleton", b);
        b.add (2);
        print ("two", b);
        b.reverse ();
        print ("reverse two", b);
        b.reverse ();
        print ("reverse again", b);
        for (double i = 3; i < 7; i++) {
            b.add (i);
            b.add (i);
        }
        print ("bigger list", b);
        b.reverse ();
        print ("reversed", b);
    }
    private static void testRemove () {
        MyLinked b = new MyLinked ();
        b.remove (4);
        print ("removed 4 from empty", b);
        b.add (1);
        b.remove (4);
        print ("removed 4 from singelton", b);
        b.remove (1);
        print ("removed 1 from singelton", b);
        for (double i = 1; i < 5; i++) {
            b.add (i);
            b.add (i);
        }
        for (double i = 1; i < 5; i++) {
            b.add (i);
            b.add (i);
            b.add (i);
            b.add (i);
            b.add (i);
        }
        print ("longer list", b);
        b.remove (9);
        print ("removed all 9s", b); // does nothing
        b.remove (3);
        print ("removed all 3s", b);
        b.remove (1);
        print ("removed all 1s", b);
        b.remove (4);
        print ("removed all 4s", b);
        b.remove (2);
        print ("removed all 2s", b); // should be empty
    }
*/
    
    
    public static void testDelete () {
        MyLinked b = new MyLinked ();
        b.add (1);
        //print ("singleton", b);
        //System.out.print(b);
        Assert.assertTrue(b.first.item == 1);
        //System.out.print(b);
        b.delete (0);
        //print ("deleted", b);
        Assert.assertTrue(b.isEmpty());
        for (double i = 1; i < 13; i++) {
            b.add (i);
        }
      
        Assert.assertTrue(b.first.item == 12);
        //print ("bigger list", b);
        b.delete (0);
      //  print ("deleted at beginning", b);

        Assert.assertTrue(b.first.item == 11);
      //  print ("deleted at end", b);
        b.delete (10);
        Node tmp = b.first;
        for (int i = 0; i < 9; i++)
        	tmp = tmp.next;
        Assert.assertTrue(tmp.item == 2);
        b.delete (4);
       // print ("deleted in middle", b);
        
    }
    
    public static void testReverse () {
    	 MyLinked b = new MyLinked ();
         b.reverse ();	
       //  print ("reverse empty", b);

         Assert.assertTrue(b.isEmpty());	
         b.add (1);
     //    print ("singleton", b);

         Assert.assertTrue(b.size() == 1);	
         Assert.assertTrue(b.first.item == 1);	
         b.reverse ();
        // print ("reverse singleton", b);

         Assert.assertTrue(b.first.item == 1);
         Assert.assertTrue(b.size() == 1);
         b.add (2);
       //  print ("two", b);

         Assert.assertTrue(b.size() == 2);
         Assert.assertTrue(b.first.item == 2);
         Assert.assertTrue(b.first.next.item == 1);
         b.reverse ();
       //  print ("reverse two", b);

         Assert.assertTrue(b.first.item == 1);
         Assert.assertTrue(b.first.next.item == 2);
         b.reverse ();
       //  print ("reverse again", b);

         Assert.assertTrue(b.first.item == 2);
         Assert.assertTrue(b.first.next.item == 1);
         for (double i = 3; i < 7; i++) {
             b.add (i);
             b.add (i);
         }
       //  print ("bigger list", b);

         Assert.assertTrue(b.size() == 10);	
         b.reverse ();
      //   print ("reversed", b);

         } 
    
    
    public static void testRemove () {
        MyLinked b = new MyLinked ();
        b.remove (4);
       // print ("removed 4 from empty", b);

        Assert.assertTrue(b.first == null);	
        b.add (1);
        b.remove (4);
       // print ("removed 4 from singelton", b);

        Assert.assertTrue(b.size() == 1);
        b.remove (1);
      //  print ("removed 1 from singelton", b);

        Assert.assertTrue(b.isEmpty());
        for (double i = 1; i < 5; i++) {
            b.add (i);
            b.add (i);
        }
        for (double i = 1; i < 5; i++) {
            b.add (i);
            b.add (i);
            b.add (i);
            b.add (i);
            b.add (i);
        }
     //   print ("longer list", b);

        Assert.assertTrue(b.size() == 28);	
        Assert.assertTrue(b.first.item == 4);
        b.remove (9);
      //  print ("removed all 9s", b); // does nothing

        Assert.assertTrue(b.size() == 28); 
        b.remove (3);
     //   print ("removed all 3s", b);

        Assert.assertTrue(b.size() == 21);	
        Assert.assertTrue(b.first.item == 4);	
        b.remove (1);
     //   print ("removed all 1s", b);

        Assert.assertTrue(b.size() == 14);
        b.remove (4);
      //  print ("removed all 4s", b);

        Assert.assertTrue(b.size() == 7);	
        Assert.assertTrue(b.first.item == 2);
        b.remove (2);
      //  print ("removed all 2s", b); // should be empty

        Assert.assertTrue(b.isEmpty()); 
        Assert.assertTrue(b.first == null);
    }

}

































